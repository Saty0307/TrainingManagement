package com.cg.tma.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tma.entities.Admin;
import com.cg.tma.entities.Trainee;
import com.cg.tma.service.TraineeServices;


@Controller
public class TraineeController 
{
	@Autowired
	TraineeServices tsi;
	Trainee deletrain = null;
	@RequestMapping("start")
	public String showLogin(Model model)
	{	
		Admin admin= new Admin();
		model.addAttribute("admin",admin);
		return "login";
		
	}
	
	@RequestMapping("login")
	public String CheckAdmin(@Valid@ModelAttribute("admin")Admin admin,BindingResult res,Model model)
	{
		if(res.hasErrors())
		{
			model.addAttribute("admin",admin);
			return "login";
		}
		else
		{
			if(admin.getU_Name().equals("satyam")&& admin.getPswd().equals("kashmiri"))
			{
				return "menu";
			}
			else
			{
				return "login";
			}
		}
	}
	
	@RequestMapping("add")
	public String AddTrainee(Model model)
	{
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		return "add";
	}
	
	@RequestMapping("addmenu")
	public String showAddMenu(@ModelAttribute("trainee")Trainee trainee,Model model)
	{
			tsi.addTrainee(trainee);
			model.addAttribute("trainee",trainee);
			return "menu";
	}
	
	@RequestMapping("delete")
	public String showDelMenu(Model model)
	{
		Trainee deltrainee = new Trainee();
		model.addAttribute("deltrainee",deltrainee);
		model.addAttribute("Flag",false);
		return "delete";
	}
	
	@RequestMapping("delmenu")
	public String Delete(@RequestParam("Flag")Boolean Flag,
			@ModelAttribute("deltrainee")Trainee deltrainee,Model model)
	{
		
		deletrain= tsi.fetchTrainee(deltrainee.getTraineeId());
		model.addAttribute("delinfo",deletrain);
		model.addAttribute("Flag", true);
		return "delete";
	}
	
	@RequestMapping("del")
	public String Del(@ModelAttribute("delinfo")Trainee delinfo,Model model)
	{
		//System.out.println(deletrain.getTraineeId());
		tsi.delTrainee(deletrain.getTraineeId());
		return "menu";
	}
	
	
	@RequestMapping("modify")
	public String modify(Model model)
	{
		Trainee modt= new Trainee();
		model.addAttribute("modt", modt);
		model.addAttribute("Flag",false);
		return "modify";
	}
	
	@RequestMapping("modtrain")
	public String modt(@RequestParam("Flag")Boolean Flag,
			@ModelAttribute("modt")Trainee modt,Model model)
	{
		Trainee modinfo= tsi.fetchTrainee(modt.getTraineeId());
		model.addAttribute("modinfo",modinfo);
		model.addAttribute("Flag",true);
		return "modify";
	}
	
	@RequestMapping("mod")
	public String Mod(@ModelAttribute("modinfo")Trainee modinfo,Model model)
	{
		
		tsi.modtrainee(modinfo);
		return "menu";
	}
	
	@RequestMapping("retrieve")
	public String showRetrive(Model model)
	{
		Trainee retrainee = new Trainee();
		model.addAttribute("retrainee",retrainee);
		model.addAttribute("Flag",false);
		return "retrieve";
	}
	
	@RequestMapping("retrmenu")
	public String Retrieve(@RequestParam("Flag")Boolean Flag,@ModelAttribute("retrainee")
							Trainee retrainee,Model model)
	{
		
		Trainee retrain= tsi.fetchTrainee(retrainee.getTraineeId());
		model.addAttribute("retrain", retrain);
		model.addAttribute("Flag",true);
		return "retrieve";
	}
	
	
	@RequestMapping("retrieveAll")
	public String showAllRetrieve(Model model)
	{
		List<Trainee> mlist= tsi.fetchAllTrainee();
		model.addAttribute("mlist", mlist);
		return "retrieveAll";
	}
	
	
}
