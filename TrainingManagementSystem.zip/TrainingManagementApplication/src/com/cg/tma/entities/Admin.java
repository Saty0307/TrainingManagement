package com.cg.tma.entities;
import javax.validation.constraints.NotNull;



public class Admin 
{
	@NotNull(message="Cannot be Empty")
	private String U_Name;
	@NotNull(message="Cannot be Empty")
	private String Pswd;
	public Admin() 
	{	
	}
	public String getU_Name() {
		return U_Name;
	}
	public void setU_Name(String u_Name) {
		U_Name = u_Name;
	}
	public String getPswd() {
		return Pswd;
	}
	public void setPswd(String pswd) {
		Pswd = pswd;
	}
	@Override
	public String toString() {
		return "Admin [U_Name=" + U_Name + ", Pswd=" + Pswd + "]";
	}
	
	
	
}
