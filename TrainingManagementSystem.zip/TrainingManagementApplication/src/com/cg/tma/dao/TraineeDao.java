package com.cg.tma.dao;

import java.util.List;


import com.cg.tma.entities.Trainee;

public interface TraineeDao 
{
	 void addTrainee(Trainee trn);
	 void delTrainee(Integer trn);
	 Trainee modtrainee(Trainee trn);
	 Trainee fetchTrainee(Integer trn);
	 List<Trainee>fetchAllTrainee();
}
