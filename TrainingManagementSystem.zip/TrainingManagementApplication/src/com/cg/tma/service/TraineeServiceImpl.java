package com.cg.tma.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tma.dao.TraineeDao;
import com.cg.tma.entities.Trainee;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeServices
{
	
	@Autowired
	TraineeDao tdao;
	

	@Override
	public void addTrainee(Trainee trn) 
	{
		tdao.addTrainee(trn);
	}

	@Override
	public void delTrainee(Integer trn) 
	{
		 tdao.delTrainee(trn);
	}

	@Override
	public Trainee modtrainee(Trainee trn) 
	{
		return tdao.modtrainee(trn);
	}

	@Override
	public Trainee fetchTrainee(Integer trn)
	{
		
		return tdao.fetchTrainee(trn);
	}

	@Override
	public List<Trainee> fetchAllTrainee() 
	{
		
		return tdao.fetchAllTrainee();
	}

}
