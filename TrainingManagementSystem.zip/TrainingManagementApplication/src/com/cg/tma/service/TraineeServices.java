package com.cg.tma.service;

import java.util.List;

import com.cg.tma.entities.Trainee;

public interface TraineeServices 
{
	 void addTrainee(Trainee trn);
	 void delTrainee(Integer trn);
	 Trainee modtrainee(Trainee trn);
	 Trainee fetchTrainee(Integer trn);
	 List<Trainee>fetchAllTrainee();
}
